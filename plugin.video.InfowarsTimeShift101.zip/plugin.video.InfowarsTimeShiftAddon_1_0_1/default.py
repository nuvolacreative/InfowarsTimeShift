# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2015 - Simple TechNerd
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.InfowarsTimeShift'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("Infowars TimeShift", "user/RonGibsonCF", 'https://pbs.twimg.com/profile_images/469222295710355457/4sP_eEA-_400x400.jpeg'),
        ("", "user/RonGibsonCF", 'https://pbs.twimg.com/profile_images/469222295710355457/4sP_eEA-_400x400.jpeg'),
        ("Alex Jones", "user/TheAlexJonesChannel", 'https://yt3.ggpht.com/-DbNegouDvyU/AAAAAAAAAAI/AAAAAAAAAAA/QyDM_-5eUFc/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Anthony Gucciardi", "channel/UCu1CepJGKypinrhLmwdbEIQ", 'https://yt3.ggpht.com/-D1eJGRhxrgE/AAAAAAAAAAI/AAAAAAAAAAA/yCvGc1FuKsE/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Dan Bidondi", "channel/UC590ipkGp-eblqfLIZdMHIA", 'https://yt3.ggpht.com/-1Wm4LP7kN44/AAAAAAAAAAI/AAAAAAAAAAA/P08n-OO3_Zw/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Darrin McBreen", "channel/UCg8TRl7RaRKma8-pn8HNGIw", 'https://yt3.ggpht.com/-PU26z5hqjwg/AAAAAAAAAAI/AAAAAAAAAAA/hHH8RVPjVq0/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("David Kinght", "channel/UCXXjBMQdTJfrSpDRg41ridQ", 'https://yt3.ggpht.com/-jHGsGqVfTaY/AAAAAAAAAAI/AAAAAAAAAAA/-75d8kWJ-WY/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Jakari Jackson", "channel/UCj5yqwsIcSxSbGYz16FqjZw", 'https://yt3.ggpht.com/-HsCQHKm4ZVs/AAAAAAAAAAI/AAAAAAAAAAA/ZsfSAg0DkkI/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Jon Bowne", "user/warforyourmindHD", 'https://yt3.ggpht.com/-RQg3mTuIhTU/AAAAAAAAAAI/AAAAAAAAAAA/r2-H70sQF4U/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Kit Daniels / Resistance News", "channel/UCG-JtVoCTdSB6Wbre7W_mFQ", 'https://yt3.ggpht.com/-wdAnu505Uxs/AAAAAAAAAAI/AAAAAAAAAAA/36PMUKP8FZo/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Lee Ann McAdoo", "user/InfoPlanetWars", 'https://yt3.ggpht.com/-jj_9-95y0j0/AAAAAAAAAAI/AAAAAAAAAAA/9dgMZKpqJIE/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Mark Dice", "channel/UCzUV5283-l5c0oKRtyenj6Q", 'https://yt3.ggpht.com/-s8YZScRJNgA/AAAAAAAAAAI/AAAAAAAAAAA/ipwjKeDoSS0/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Paul Joseph Watson", "channel/UCittVh8imKanO_5KohzDbpg", 'https://yt3.ggpht.com/-fIb6IwufvwI/AAAAAAAAAAI/AAAAAAAAAAA/Smnj7cy5o0Y/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("", "user/RonGibsonCF", 'https://pbs.twimg.com/profile_images/469222295710355457/4sP_eEA-_400x400.jpeg'),
        ("THE INFOWARRIOR Channel", "channel/UCeR_8eEz8qpG0z0jX8r1-wA", 'https://yt3.ggpht.com/-RJ2vgMAO-JU/AAAAAAAAAAI/AAAAAAAAAAA/iZhQHkuqtm4/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("AlexJonesInfoHD Channel", "channel/UC9VuhiL3OYG3PIQr0q73KJQ", 'https://yt3.ggpht.com/-8kS9tliLMME/AAAAAAAAAAI/AAAAAAAAAAA/Jd9TVWWCDKQ/s100-c-k-no-rj-c0xffffff/photo.jpg'),
        ("Infowars Tonight Channel", "channel/UCzzd06zn5k6m_xwYmgMVzZw", 'https://i.ytimg.com/i/zzd06zn5k6m_xwYmgMVzZw/mq1.jpg?v=4ee95e9c'),
        ("", "user/RonGibsonCF", 'https://pbs.twimg.com/profile_images/469222295710355457/4sP_eEA-_400x400.jpeg'),
        ("Global Healing Center", "channel/UCUYI_ovPG0xO3mCjVCWvcbA", 'https://yt3.ggpht.com/-EleHxlVukUQ/AAAAAAAAAAI/AAAAAAAAAAA/fU3ehB1h_JY/s100-c-k-no-rj-c0xffffff/photo.jpg'),
]



# Entry point
def run():
    plugintools.log("InfowarsTimeShift.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("InfowarsTimeShift.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()